//
//  EnergyFunctionQueue.h
//  Backbeater
//
//  Created by Alina Kholcheva on 2015-07-08.
//

#import <Foundation/Foundation.h>

@interface EnergyFunctionQueue : NSObject


-(Float32) push:(Float32)value;
-(void)clear;

@end
